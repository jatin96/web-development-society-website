<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login PHP</title>
</head>

<body>
<?php
include('function.php');
$email=validate($_POST['email']);
$pass=validate($_POST['pass']);
echo $email." ".$pass;
$con=dbconnect();
$query="select password,name from user where emailid like '$email'";
$res=$con->query($query);
if($res->num_rows==0){
	echo "Invalid username";
}
else{
	while($arr=$res->fetch_array()){
		if($arr['password']==$pass){
			echo "successfully logged in".$arr['name'];
			session_start();
			$_SESSION['email']=$email;
			$_SESSION['name']=$arr['name'];
			?>
            <a href="profile.php">Click Here</a> to go to profile page.
            <?php
		}
		else echo "Invalid password";
	}
}

?>
</body>
</html>