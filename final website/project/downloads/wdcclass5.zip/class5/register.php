<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Register PHP</title>
</head>

<body>
<?php
function validate($val){
	$val=htmlentities(trim($val));
	return $val;
}
$name=validate($_POST['fname']);
$email=validate($_POST['email']);
$password=validate($_POST['pass']);
$add=validate($_POST['address']);
$number=validate($_POST['no']);
$secutiyq=validate($_POST['security']);
$secutiya=validate($_POST['ans']);

$dbhost="localhost";
$dbuname="root";
$dbpassword="";		//your database password
$dbname="wdc";		//your database name
$con=new MySQLi($dbhost,$dbuname,$dbpassword,$dbname);

if($con->connect_errno){
	die("Not able to".$con->connect_error);	
}
else echo "Database connected :)";

$query="INSERT INTO `wdc`.`user` (`name`, `emailid`, `password`, `address`, `contactno`, `securityq`, `securityans`) VALUES ('$name', '$email', '$password', '$add', '$number', '$secutiyq', '$secutiya');";

$con->query($query);
if($con->errno){
	die("Sorry could not execute query".$con->error);	
}
else echo "Successfully inserted data";
?>
</body>
</html>