<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php
function sum($a,$b){
	$c=$a+$b;
	return $c;	
}
echo sum(3,5);
?>
</body>
</html>