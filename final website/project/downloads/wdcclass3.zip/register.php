<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php
	function validate($a){
		$b=htmlentities($a);
		$c=trim($b);
		return $c;
	}
	/*$name=htmlentities($_GET['fname']);
	$name=trim($name);
	*/
	
	$i=2;
	$a="vand";
	switch($i){
		case 1: echo "1";
			break;
		case 2: echo "2";
			break;
		default: echo "none";	
	}
//	var_dump($a);
	echo "<br>";
	$name=validate($_GET['fname']);
	$password=validate($_GET['password']);
	if($name==""){
		echo "Name Empty";
	}
	else {
		echo "Your name is ".$name."";
	}
	$i=0;
	for($i=0;$i<10;$i++){
		echo "$i\n";
	}
?>
</body>
</html>