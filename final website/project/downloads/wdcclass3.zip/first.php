<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>PHP FIrst Page</title>
</head>

<body>
<?php
	echo "Hello World!!";
?>
</body>
</html>