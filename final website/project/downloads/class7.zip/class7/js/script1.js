// JavaScript Document

function validate()
{
	//return false;
	var form = document.forms['jstute'];
	//alert(form.elements[0].value);
	//alert(form.elements.namedItem('name').value);
	//alert(document.getElementById('name').value);
	var name = document.getElementById('name');
	var pass = document.getElementById('pwd');
	var repass = document.getElementById('repwd');
	var mobile = document.getElementById('mobile');
	if(name.value.replace(/\s/g, '') == "")
	{
		alert("Name Can't be empty");
		return false;
	}
	else if(pass.value != repass.value)
	{
		alert("Passwords don't match");
		return false;
	}
	else if(mobile.value.length < 10)
	{
		alert("Invalid Mobile Number");
		return false;
	}
	else
		return true;
}

function checkMobile(obj)
{
	var regEx = /\D/g;
	if(regEx.test(obj.value) == true)
		obj.value = obj.value.replace(regEx, "");
}

