// JavaScript Document

var global = "";

function takeInfo()
{
	global = prompt('What is your name?', 'abcd');	
}

function showInfo()
{
	var resp = confirm('Do you really want to display the name??');
	if(resp == 1)
	{
		var obj = document.getElementById('name');
		if(global == "")		//Show == and ===
		{
			obj.textContent= "<i>Please first enter a name using Take Info Button</i>";
		}
		else
		{
			obj.innerHTML = "Your name is " + global;
		}
	}
	else
	{
		alert("You Refused :(");
	}
}